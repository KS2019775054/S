
public class SlidingPuzzleDriver {
	public static void main(String[] args) {
		SlidingPuzzle puzzle = new SlidingPuzzle();
		puzzle.go();
	}

}
